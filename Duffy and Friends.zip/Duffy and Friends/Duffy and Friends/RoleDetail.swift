import SwiftUI

// 定義 RoleDetail 結構，用於顯示角色的詳細信息
struct RoleDetail: View {
    let role: Role  // 從外部傳入的角色資料
    
    var body: some View {
        ScrollView{ // 使用ScrollView來支持滾動
            LazyVStack{ // 使用LazyVStack進行垂直排列，以支持懶加載視圖
                Image(role.name) // 顯示角色圖片
                    .resizable()
                    .scaledToFit()
                Text(role.CName + " (" + role.name + ")") // 顯示角色的中文名稱和英文名稱
                    .font(.largeTitle) // 設置字體大小
                Text("性別：" + role.Gender) // 顯示性別信息
                Text("特徵：" + role.Characteristic) // 顯示特徵描述
                Text("性格：" + role.Disposition) // 顯示性格描述
                Text("愛好：" + role.Hobby) // 顯示愛好描述
                Image(role.TitleStory) // 顯示標題故事的圖片
                    .resizable()
                    .scaledToFit()
                    .frame(width: 350)  // 設置圖片寬度
                Text(role.Story) // 顯示角色故事描述
            }
            .navigationTitle(role.name) // 將導航標題設置為角色名稱
        }
    }
}

// 在預覽模式中顯示RoleDetail視圖，使用demoRole作為示範角色
#Preview() {
    RoleDetail(role: .demoRole)
}
