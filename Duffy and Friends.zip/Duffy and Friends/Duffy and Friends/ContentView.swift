import SwiftUI

// 定義 ContentView 結構體，該結構將作為應用程式的主要畫面
struct ContentView: View {
    var body: some View {
        // 創建 TabView，它包含多個選項卡
        TabView{
            // 第一個選項卡 Home，使用 Home() 視圖
            Home()
                .tabItem {
                    // 使用 Label 顯示標籤文字和系統圖示 "house.lodge"
                    Label("首頁", systemImage: "house.lodge")
                }
            // 第二個選項卡 Characters，使用 Characters() 視圖
            Characters()
                .tabItem {
                    // 使用 Label 顯示標籤文字和系統圖示 "person.fill"
                    Label("角色", systemImage: "person.fill")
                }
            // 第三個選項卡 Shop，使用 Shop() 視圖
            Shop()
                .tabItem {
                    // 使用 Label 顯示標籤文字和系統圖示 "gift.fill"
                    Label("送禮", systemImage: "gift.fill")
                }
        }
    }
}

// 在預覽模式中顯示 ContentView
#Preview {
    ContentView()
}
