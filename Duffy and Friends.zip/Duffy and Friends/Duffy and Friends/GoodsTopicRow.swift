import SwiftUI

// 定義GoodsTopic結構，表示商品主題的詳細資訊
struct GoodsTopic {
    let name: String    // 商品主題的名稱
    let Gname: String   // 商品主題的中文名稱
}

// 通過擴展GoodsTopic結構，添加一個名為demoGoodsTopic的靜態屬性，用於示範一個特定的商品主題
extension GoodsTopic {
    static let demoGoodsTopic = GoodsTopic(name: "goods_duffy", Gname: "Duffy")
}

// 定義GoodsTopicRow結構，用於在清單中顯示商品主題的縮略信息
struct GoodsTopicRow: View {
    let goodsTopic: GoodsTopic
    
    var body: some View {
        Image(goodsTopic.name)
            .resizable()
            .scaledToFit()
            .frame(height: 100)  // 設置圖像的高度
            .clipShape(Circle())  // 將圖像裁剪為圓形
    }
}

// 在預覽模式中顯示GoodsTopicRow視圖，使用demoGoodsTopic作為示範商品主題
#Preview {
    GoodsTopicRow(goodsTopic: .demoGoodsTopic)
}
