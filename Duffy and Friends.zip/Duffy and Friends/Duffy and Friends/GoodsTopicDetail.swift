import SwiftUI

// 定義GoodsTopicDetail結構，用於顯示商品主題的詳細信息
struct GoodsTopicDetail: View {
    let goodsTopics = [
        GoodsTopic(name: "goods_duffy", Gname: "Duffy"),
        GoodsTopic(name: "goods_shellieMay", Gname: "SheiileMay"),
        GoodsTopic(name: "goods_gelatoni", Gname: "Gelatoni"),
        GoodsTopic(name: "goods_stellaLou", Gname: "StellaLou"),
        GoodsTopic(name: "goods_cookieAnn", Gname: "CookieAnn"),
        GoodsTopic(name: "goods_olu Mel", Gname: "OluMel"),
        GoodsTopic(name: "goods_linaBell", Gname: "LinaBell")
    ]
    let goodsTopic: GoodsTopic  // 從外部傳入的商品主題資料
    
    var body: some View {
        let columns = Array(repeating: GridItem(), count: 2)  // 創建具有2列的網格布局
        
        List {  // 使用List來顯示內容，支持滾動
            ScrollView(.horizontal) {  // 水平滾動的ScrollView
                LazyHStack(pinnedViews: [.sectionHeaders]) {  // 使用LazyHStack來懶加載橫向視圖
                    ForEach(0..<7) { index in
                        NavigationLink {  // 點擊後導航到商品主題的詳細信息
                            GoodsTopicDetail(goodsTopic: goodsTopics[index])
                                .background(Color(red: 253/255, green: 241/255, blue: 224/255))
                        } label: {
                            GoodsTopicRow(goodsTopic: goodsTopics[index])  // 顯示商品主題的縮略信息
                        }
                        .edgesIgnoringSafeArea(.top)  // 忽略安全區域的邊緣
                        .navigationBarBackButtonHidden()  // 隱藏導航列的返回按鈕
                    }
                }
            }
            .listRowSeparator(.hidden)  // 隱藏行之間的分隔線
            .listRowBackground(Color(red: 253/255, green: 241/255, blue: 224/255))  // 設置行的背景顏色
            
            ScrollView {  // 垂直滾動的ScrollView
                LazyVGrid(columns: columns) {  // 使用網格布局來顯示商品圖像
                    ForEach(1..<11) { index in
                        Image(goodsTopic.Gname + String(index))  // 顯示商品圖像
                            .resizable()
                            .scaledToFit()
                    }
                }
            }
            .listRowBackground(Color(red: 253/255, green: 241/255, blue: 224/255))  // 設置行的背景顏色
        }
        .listStyle(.plain)  // 設置清單樣式為普通樣式
        .background(Color(red: 253/255, green: 241/255, blue: 224/255))  // 設置整個視圖的背景顏色
    }
}

// 在預覽模式中顯示GoodsTopicDetail視圖，使用demoGoodsTopic作為示範商品主題
#Preview {
    GoodsTopicDetail(goodsTopic: .demoGoodsTopic)
}
