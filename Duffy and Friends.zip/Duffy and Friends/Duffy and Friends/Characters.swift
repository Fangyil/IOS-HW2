import SwiftUI

// 定義 Characters 結構，表示角色清單視圖
struct Characters: View {
    // 創建包含不同性別角色的陣列
    let Femaleroles = [
        Role(name: "ShellieMay",CName: "雪莉玫",Gender: "Female",
             Characteristic: "長長的睫毛、藍色眼睛、頭戴蝴蝶結、腳掌和屁股上有著米奇形狀的印記",
             Disposition: "樂觀開朗",Hobby: "旅遊、打扮、認識新朋友",
             TitleStory: "TitleStoryShellieMay",Story: "有了達菲陪伴米奇環遊世界後，米妮又特意為達菲製作新的朋友，於是邊有了雪梨玫，後來達菲更與雪梨玫成為了好朋友。她和達菲一樣頭又著和米奇一樣的形狀，擁有粉紅色毛髮，是達菲熊家族第二個出現的角色。"),
        Role(name: "StellaLou",CName: "星黛露",Gender: "Female",
             Characteristic: "紫色的毛髮、長長的耳朵有著米奇的印記",
             Disposition: "有夢想、快樂、勤奮堅定",Hobby: "跳舞，夢想成為舞蹈家",
             TitleStory: "TitleStoryStellaLou",Story: "達菲在練習舞蹈時，看見了一隻可愛的兔子在跳舞。因為跳得搖搖欲墜讓達菲不禁擔心起兔子是否會跌倒受傷，而上前關心。這位兔子名叫星黛露，她向達菲打招呼，並說著夢想是成為舞者。「是睡覺時會做夢的那種夢嗎？」達菲問，「不是啦！是想要達成的夢想～」星黛露兔語畢，便又開始跳起舞來。達菲看著星黛露兔的舞步，讚嘆著說：「現在的你，像星星一樣閃耀。」她聽了好開心，覺得自己離夢想又更進一步了！" ),
        Role(name: "CookieAnn",CName: "可琦安",Gender: "Female",
             Characteristic: "黃色毛髮、頭戴的廚師帽、繫著粉紅色的蝴蝶結、有毛茸茸而且垂著的長耳朵",
             Disposition: "活潑熱情",Hobby: "研究創意食譜",
             TitleStory: "TitleStoryCookieAnn",Story: "可琦安是個熱愛創作的廚師。有一天達菲拿著棉花糖在路上散步，突然，一座鬆餅疊成的小山映入眼簾。一不小心，捧著疊疊鬆餅的可琦安與達菲撞在一起，鬆餅便漫天飛舞，達菲的棉花糖也撞飛了。可琦安便想到一個好主意，那就是將鬆餅與棉花糖一起吃，於是用手上僅剩的一片鬆餅接住了棉花糖，並分給達菲吃。達菲對於這組合的滋味半信半疑，可琦安要達菲相信她。可琦安看著吃得津津有味的達菲，再想到她的新作品鬆餅結合棉花糖，因此開心不已。"),
        Role(name: "LinaBell",CName: "玲娜貝兒",Gender: "Female",
             Characteristic: "粉紅色的毛髮、長長的大尾巴、頭戴紫色蘭花、隨身帶著放大鏡",
             Disposition: "聰明靈敏、活潑有趣、好奇",Hobby: "探索和解決謎團、喜歡大自然",
             TitleStory: "TitleStoryLinaBell",Story: "達菲和他的好朋友米奇在森林裡追逐蝴蝶時迷路了。在森林中遇見拿著放大鏡正在探險的玲娜貝兒，他拿著放大鏡東瞧瞧、西瞧瞧，好奇達菲是從哪邊來的。")
    ]
    let Maleroles = [
        Role(name: "Duffy",CName: "達菲",Gender: "Male",
                          Characteristic: "腳掌和屁股上有著米奇形狀的印記",
                          Disposition: "害羞",Hobby: "旅遊、拍照、認識新朋友",
                          TitleStory: "TitleStoryDuffy",Story: "某天，米奇又要長途出航，在米奇出發的前一個夜晚，米妮非常擔心米奇一個人航海會孤單寂寞，而縫製了一隻泰迪熊當作米奇出航的船伴。米妮縫製完成後放在圓筒水手袋（duffle bag）中拿給米奇。米奇看到米妮精心縫製的泰迪熊後十分開心，並決定將裝在水手袋的他取名為達菲。從此米奇不論航行到哪處，都帶著達菲出遊，只要達菲在身邊，米奇的心情總是既愉悅又明朗。"),
        Role(name: "Gelatoni",CName: "傑拉多尼",Gender: "Male",
             Characteristic: "像畫筆般的尾巴、粉紅色耳朵、有跟畫家帽同色的眼睛",
             Disposition: "聰明、可愛",Hobby: "畫畫、認識新朋友",
             TitleStory: "TitleStoryGelatoni",Story: "在與米奇的一次散步中，達菲不小心弄掉了手中的義式冰淇淋，這時恰好遇到一隻帶著藍色畫家帽的貓咪，這隻畫家貓咪安慰著達菲：「沒事的，對了！我叫傑拉多尼，看我的厲害!」說完傑拉多尼便將掉落的冰淇淋當成顏料開始作畫。達菲看了好興奮，於是也畫了一幅米奇的畫像。畫好後兩人交換了畫作，從此成為了好朋友。"),
        Role(name: "Olu Mel",CName: "奧樂米拉",Gender: "Male",
             Characteristic: "圓圓的腦袋、隨身攜帶者烏克麗麗",
             Disposition: "憨厚可愛",Hobby: "音樂、喜歡大自然",
             TitleStory: "TitleStoryOlu Mel",Story: "因為雪莉玫的生日快到了，米奇與達菲划著小船一起出門尋找雪莉玫的禮物。在進入海灣時，耳邊傳來悅耳的烏克麗麗聲，接著一隻小海龜出現在眼前，他告訴達菲，自己名叫奧樂米拉，興趣是作曲，並邀請達菲一起唱歌。達菲聽到奧樂米拉的歌聲後，認定這首歌曲是獻給雪莉玫最好的禮物。於是將奧樂米拉帶到雪莉玫的生日派對，大夥兒伴著奧樂米拉創作的歌曲一起唱著歌，幫雪莉玫度過開心的生日。")]
    var body: some View {
        NavigationStack{
            List{
                // 男性角色部分
                Section {
                    ForEach(0..<3){index in
                        NavigationLink {
                            RoleDetail(role: Maleroles[index])
                                .background(
                                    LinearGradient(gradient: Gradient(colors: [Color(red: 253/255, green: 241/255, blue: 224/255),Color(red: 252/255, green: 217/255, blue: 192/255)]), startPoint: .top, endPoint: .bottom)
                                        )
                        } label: {
                            RoleRow(role: Maleroles[index])
                        }
                        .listRowSeparator(.hidden)
                    }
                    .listRowBackground(Color(red: 253/255, green: 241/255, blue: 224/255))
                }header: {
                    Text("Male")
                }
                
                // 女性角色部分
                Section {
                    ForEach(0..<4){index in
                        NavigationLink {
                            RoleDetail(role: Femaleroles[index])
                                .background(
                                    LinearGradient(gradient: Gradient(colors: [Color(red: 255/255, green: 226/255, blue: 225/255),Color(red: 242/255, green: 195/255, blue: 229/255)]), startPoint: .top, endPoint: .bottom)
                                        )
                                .transition(.scale)
                                .onAppear()
                        } label: {
                            RoleRow(role: Femaleroles[index])
                        }
                        .listRowSeparator(.hidden)
                    }
                    .listRowBackground(Color(red: 255/255, green: 226/255, blue: 225/255))
                }header: {
                    Text("Female")
                }
                
            }
            .listStyle(.plain)
            .background(
                LinearGradient(gradient: Gradient(colors: [Color(red: 253/255, green: 241/255, blue: 224/255),Color(red: 255/255, green: 226/255, blue: 225/255)]), startPoint: .top, endPoint: .bottom)
                    )
        }
    }
}

// 在預覽模式中顯示 Characters 視圖
#Preview {
    Characters()
}
