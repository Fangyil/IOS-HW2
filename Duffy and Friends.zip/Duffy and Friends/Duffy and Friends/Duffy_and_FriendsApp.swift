import SwiftUI

@main
struct Duffy_and_FriendsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
