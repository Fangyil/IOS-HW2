import SwiftUI

struct Duffy: View {
    var body: some View {
        Text("Hello, Duffy!")
    }
}

#Preview {
    Duffy()
}
