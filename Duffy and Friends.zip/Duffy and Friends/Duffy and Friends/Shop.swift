import SwiftUI

// 定義Shop視圖，用於顯示商品主題和商品詳細信息
struct Shop: View {
    let goodsTopics = [
        GoodsTopic(name: "goods_duffy", Gname: "Duffy"),
        GoodsTopic(name: "goods_shellieMay", Gname: "SheiileMay"),
        GoodsTopic(name: "goods_gelatoni", Gname: "Gelatoni"),
        GoodsTopic(name: "goods_stellaLou", Gname: "StellaLou"),
        GoodsTopic(name: "goods_cookieAnn", Gname: "CookieAnn"),
        GoodsTopic(name: "goods_olu Mel", Gname: "OluMel"),
        GoodsTopic(name: "goods_linaBell", Gname: "LinaBell")
    ]
    
    var body: some View {
        let columns = Array(repeating: GridItem(), count: 2)
        
        // 使用NavigationStack包裹視圖，以支援導航功能
        NavigationStack {
            List {
                ScrollView(.horizontal) {
                    LazyHStack {
                        ForEach(0..<7) { index in
                            NavigationLink {
                                GoodsTopicDetail(goodsTopic: goodsTopics[index])
                                    .background(Color(red: 253/255, green: 241/255, blue: 224/255))
                            } label: {
                                GoodsTopicRow(goodsTopic: goodsTopics[index])
                            }
                            .edgesIgnoringSafeArea(.top)
                            .navigationBarBackButtonHidden()
                        }
                    }
                }
                .listRowBackground(Color(red: 253/255, green: 241/255, blue: 224/255))
                
                ScrollView {
                    LazyVGrid(columns: columns) {
                        ForEach(1..<11) { index in
                            Image("Duffy" + String(index))
                                .resizable()
                                .scaledToFit()
                        }
                    }
                }
                .listRowBackground(Color(red: 253/255, green: 241/255, blue: 224/255))
            }
            .listStyle(.plain)
            .background(Color(red: 253/255, green: 241/255, blue: 224/255))
        }
    }
}

// 在預覽模式中顯示Shop視圖
#Preview {
    Shop()
}
