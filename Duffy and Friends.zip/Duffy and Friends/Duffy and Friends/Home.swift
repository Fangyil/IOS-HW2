import SwiftUI
import AVKit
import UIKit
// 定義 Home 結構體，這個視圖將作為主頁的一部分
struct Home: View {
    @State private var rotateDegree: Double = 0
    // 創建 HomeRoles 陣列，包含 HomeRole 結構的實例
    let HomeRoles = [HomeRole(HomePic: "HomeDuffy"),
                     HomeRole(HomePic: "HomeShellieMay"),
                     HomeRole(HomePic: "HomeGelatoni"),
                     HomeRole(HomePic: "HomeStellaLou"),
                     HomeRole(HomePic: "HomeCookieAnn"),
                     HomeRole(HomePic: "HomeOluMel"),
                     HomeRole(HomePic: "HomeLinaBell")]
    // 創建 AVPlayer 實例
    let player = AVPlayer()
    var body: some View {
        List{
            TabView{
                ForEach(0..<7){ index in
                    HomeRow(homerole: HomeRoles[index])
                }
            }
            .tabViewStyle(.page)
            .frame(height: 210)
            .listRowSeparator(.hidden)
            .listRowBackground(Color(red: 253/255, green: 241/255, blue: 224/255))
            
            // 創建超連結，連接至東京迪士尼的特定網頁
            Link(destination: URL(string: "https://www.tokyodisneyresort.jp/treasure/duffy/")!, label: {
                Image("HomeFamily")
                    .resizable()
                    .scaledToFit()
                    .listRowSeparator(.hidden)
                    .rotationEffect(.degrees(rotateDegree))
                    .animation(
                        .linear(duration: 5)
                        .repeatCount(1, autoreverses: true),
                        value: rotateDegree
                    )
                    .onAppear {rotateDegree = 360}
            })
            .listRowBackground(Color(red: 253/255, green: 241/255, blue: 224/255))
            
            // 創建另一個超連結，連接至東京迪士尼的特定網頁
            Image("HomeNews")
                .resizable()
                .scaledToFit()
                .listRowSeparator(.hidden)
                .listRowBackground(Color(red: 253/255, green: 241/255, blue: 224/255))
            Link(destination: URL(string:"https://www.tokyodisneyresort.jp/treasure/duffy/special/whitewintertimewonders/")!,label:{
                VStack(alignment: .leading){
                    Image("HomeWinter")
                        .resizable()
                        .scaledToFit()
                        .cornerRadius(20)
                    HStack(alignment: .top){
                        Text("Coming soon")
                            .padding(5)
                            .foregroundColor(.white)
                            .background(Color(red: 242/255 , green: 154/255, blue: 118/255))
                            .cornerRadius(10)
                        Text("東京迪士尼")
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                    Text("達菲&朋友的白色冬季奇蹟")
                        .foregroundColor(Color(red: 165/255, green: 140/255, blue: 96/255))
                }
                .listRowSeparator(.hidden)
            })
            .listRowBackground(Color(red: 253/255, green: 241/255, blue: 224/255))
            
            // 顯示圖像，.homeWorld 圖像應來自資源文件
            Image(.homeWorld)
                .resizable()
                .scaledToFit()
                .listRowSeparator(.hidden)
                .listRowBackground(Color(red: 253/255, green: 241/255, blue: 224/255))
            
            // 載入影片並顯示影片播放器
            let url = Bundle.main.url(forResource: "summer night melody", withExtension: "mp4")!
            VStack{
                VideoPlayer(player: AVPlayer(url: url))
                    .cornerRadius(50)
                    .frame(height: 250)
                    .padding()
                
                // 創建超連結，連接至東京迪士尼的影片頁面
                Link(destination: URL(string: "https://www.tokyodisneyresort.jp/treasure/duffy/movie/")!, label: {
                        ZStack{
                            Rectangle()
                                .cornerRadius(20)
                                .frame(width: 200)
                                .foregroundColor(.white)
                            Text("MORE")
                                .foregroundColor(.gray)
                                .bold()
                            Image(systemName: "greaterthan")
                                .foregroundColor(.gray)
                                .bold()
                                .offset(x:80)
                        }
                })
            }
            .listRowSeparator(.hidden)
            .listRowBackground(Color(red: 253/255, green: 241/255, blue: 224/255))
        }
        .listStyle(.plain)
        .background(Color(red: 253/255, green: 241/255, blue: 224/255))
    }
}
// 在預覽模式中顯示 Home 視圖
#Preview {
    Home()
}
