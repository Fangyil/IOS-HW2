import SwiftUI

// 定義 HomeRole 結構，該結構代表首頁角色，具有一個名為 HomePic 的屬性
struct HomeRole {
    let HomePic: String
}

// 通過擴展 HomeRole 結構，添加一個名為 demoHomeRole 的靜態屬性，用於示範首頁角色
extension HomeRole {
    static let demoHomeRole = HomeRole(HomePic: "HomeDuffy")
}

// 定義 HomeRow 結構，表示首頁中每個角色的行
struct HomeRow: View {
    let homerole: HomeRole
    
    var body: some View {
        // 顯示具有角色圖片的圖像視圖
        Image(homerole.HomePic)
            .resizable()
            .scaledToFit()
    }
}

// 在預覽模式中顯示 HomeRow 視圖，使用 demoHomeRole 作為示範角色
#Preview {
    HomeRow(homerole: .demoHomeRole)
}
