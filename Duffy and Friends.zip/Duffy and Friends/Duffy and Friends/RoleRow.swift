import SwiftUI

// 定義 Role 結構，表示角色的詳細資訊
struct Role {
    let name: String             // 角色名稱
    let CName: String            // 中文名稱
    let Gender: String           // 性別
    let Characteristic: String   // 特徵描述
    let Disposition: String      // 性格描述
    let Hobby: String            // 興趣愛好
    let TitleStory: String       // 標題故事
    let Story: String            // 角色故事描述
}

// 通過擴展 Role 結構，添加一個名為 demoRole 的靜態屬性，用於示範一個特定的角色
extension Role {
    static let demoRole = Role(name: "Duffy", CName: "達菲", Gender: "Male",
        Characteristic: "腳掌和屁股上有著米奇形狀的印記",
        Disposition: "害羞", Hobby: "旅遊、拍照、認識新朋友",
        TitleStory: "TitleStoryDuffy", Story: "某天，米奇又要長途出航，在米奇出發的前一個夜晚，米妮非常擔心米奇一個人航海會孤單寂寞，而縫製了一隻泰迪熊當作米奇出航的船伴。米妮縫製完成後放在圓筒水手袋（duffle bag）中拿給米奇。米奇看到米妮精心縫製的泰迪熊後十分開心，並決定將裝在水手袋的他取名為達菲（Duffy）。從此米奇不論航行到哪處，都帶著達菲出遊，只要達菲在身邊，米奇的心情總是既愉悅又明朗。")
}

// 定義 RoleRow 結構，表示在清單中顯示角色的行
struct RoleRow: View {
    let role: Role
    
    var body: some View {
        VStack {
            Image(role.name)
                .resizable()
                .scaledToFit()
                .cornerRadius(20)
            Text(role.name)
                .font(.largeTitle)
        }
    }
}

// 在預覽模式中顯示 RoleRow 視圖，使用 demoRole 作為示範角色
#Preview {
    RoleRow(role: .demoRole)
}
